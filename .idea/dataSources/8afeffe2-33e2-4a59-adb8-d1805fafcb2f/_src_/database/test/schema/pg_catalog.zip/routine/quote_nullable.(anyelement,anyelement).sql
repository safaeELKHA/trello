create function quote_nullable(anyelement) returns text
LANGUAGE SQL
AS $$
select pg_catalog.quote_nullable($1::pg_catalog.text)
$$;
